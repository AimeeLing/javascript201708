var a = require("./a"),
    b = require("./b");
console.log(b.sum(a.sum(1, 2, 3, 4)));