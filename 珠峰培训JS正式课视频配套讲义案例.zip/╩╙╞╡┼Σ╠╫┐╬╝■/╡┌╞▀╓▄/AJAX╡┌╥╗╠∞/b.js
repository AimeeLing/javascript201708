function sum() {
    return arguments[0] * 100;
}
module.exports.sum = sum;