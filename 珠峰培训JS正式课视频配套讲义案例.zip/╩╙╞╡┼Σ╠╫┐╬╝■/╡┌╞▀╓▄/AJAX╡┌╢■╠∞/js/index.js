var box = document.getElementById("box");
box.onclick = function () {
    this.style.background = "green";
};