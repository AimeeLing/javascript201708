//为我们的表格排序准备json格式的数据
//sex:0->男 1->女
var jsonAry = [
    {"name": "令狐冲", "age": 24, "score": 98, "sex": 0},
    {"name": "任盈盈", "age": 22, "score": 80, "sex": 1},
    {"name": "岳灵珊", "age": 21, "score": 88, "sex": 1},
    {"name": "岳不群", "age": 58, "score": 96, "sex": 0},
    {"name": "林平之", "age": 23, "score": 90, "sex": 0},
    {"name": "东方不败", "age": 30, "score": 100, "sex": 1}
];